package co.edu.unab.me.elementosadicionalessantiagojacome.ui.theme

import android.graphics.drawable.Icon
import android.widget.Space
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import co.edu.unab.me.elementosadicionalessantiagojacome.MainActivity
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Icon
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.OutlinedTextField
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.AlignmentLine
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Alignment
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MailOutline
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilledTonalButton
import androidx.compose.ui.modifier.modifierLocalOf
import androidx.compose.ui.node.ModifierNodeElement


@Preview(
    showBackground = true

)


@Composable
fun MainContent() {
    Column(
        modifier = Modifier.padding(12.dp),

        )

    {
        //Para poner un borde
        Card(modifier = Modifier.fillMaxWidth()) {


            Row( // PARA PONER EL CARD FULL ANCHO
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {

                Icon(
                    imageVector = Icons.Default.AccountCircle,
                    //Para ponerle alguna descripcion a la imagen
                    contentDescription = "Icon Account",
                    modifier = Modifier.size(56.dp)

                )
                Spacer(modifier = Modifier.width(12.dp))

                Column(
                    //para que se adapte todo por ese peso de 1f
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Tarjeta de Perfil")
                    Text("Descripción del Perfil")
                }
                //poner un icono que se puede dar clic en este caso los 3 puntos
                IconButton(onClick = {}) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        //no poden descripcion
                        contentDescription = null

                    )
                }

            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(
            value = "Valor Inicial",
            onValueChange = {},
            leadingIcon = {
                Icon(
//La lupa
                    imageVector = Icons.Default.Search,
                    contentDescription = null,
                )

            },//Para poner la X
            trailingIcon = {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = null,
                )
            },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        Row {
            Button(modifier = Modifier.weight(1f), onClick = {}) {
                Icon(imageVector = Icons.Default.Send, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Enviar")
            }
            FilledTonalButton(modifier = Modifier.weight(1f), onClick = {}) {
                Icon(imageVector = Icons.Default.MailOutline, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Tonal")
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
        Row(//para poner el chulito
            verticalAlignment =  Alignment.CenterVertically,
            horizontalArrangement =  Arrangement.spacedBy(12.dp))
        {
            Checkbox(checked =  true, onCheckedChange = {})
        }





    }

}