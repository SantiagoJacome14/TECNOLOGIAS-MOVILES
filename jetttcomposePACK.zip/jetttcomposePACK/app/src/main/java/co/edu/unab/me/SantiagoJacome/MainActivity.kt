package co.edu.unab.me.SantiagoJacome

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.layout.padding
import android.R.attr.content
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.ui.Alignment

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MyScreen()
        }
    }
}

//El preview es como para ayudarme a ver antes del emulador
@Preview(
    showBackground = true, //pantalla fondo
    showSystemUi = true //para que me muestre como el cel
)
@Composable //Para que sea componible le colocamos eso
fun MyScreen() {
    Column(content = {
        //Dibujar un texto
        Text(text = "Santiago Jacome", fontSize = 50.sp)
        //Siempre que usamos sp estamos hablando de textos
        Text(text = "Soy ingeniero de Sistemas", fontSize = 35.sp)
        //Imagen dentro de la columna
        /*Para crearla necesitamos un painter
          el id es para decirle en donde está la img -> id = R.localización.nombre
        */
        val painter = painterResource(id = R.drawable.imagen1)
        Image(
            painter = painter, //tambien puedo colocarlo "painterResource(id = R.drawable.imagen1)"
            //así para no crear la variable painter, sino lo coloco de una
            contentDescription = "Imagen de gato" //También se puede dejar nulo
        )
        Row(content = {
            Text(text = "Java", fontSize = 20.sp)
            Text(text = "Python", fontSize = 20.sp)
            Text(text = "C#", fontSize = 20.sp)
            Text(text = "php", fontSize = 20.sp)
        })
    })

}

@Preview(
    showSystemUi = true
)
@Composable
fun Screen2() {
    Column(
        verticalArrangement = Arrangement.Center,
        modifier = Modifier
            .padding(2.dp)
            .background(Color.Gray)
            .fillMaxSize()
    ) {
        Row(
            horizontalArrangement = Arrangement.SpaceAround,
            modifier = Modifier
                .background(Color.Cyan)
                .fillMaxWidth()
                .padding(8.dp)
        ) {

            Text(
                text = "Login",
                fontSize = 20.sp,
                modifier = Modifier
                    .background(Color.Magenta)
                    .padding(8.dp)

            )

            Text(
                text = "Profile",
                fontSize = 20.sp,
                modifier = Modifier
                    .background(Color.Yellow)
                    .padding(8.dp)
            )

            Text(
                text = "Settings",
                fontSize = 20.sp,
                modifier = Modifier
                    .background(Color.Green)
                    .padding(8.dp)
            )
        }
        Spacer(modifier = Modifier.height(16.dp))

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .background(Color.Cyan)
                .fillMaxWidth()
                .padding( 50.dp)
        ) {
            Text(
                text = "Main Tittle",
                fontSize = 20.sp,
                modifier = Modifier
                    .background(Color.Magenta)
                    .padding(8.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Description",
                fontSize = 20.sp,
                modifier = Modifier
                    .background(Color.Yellow)
                    .padding(8.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Otro elemento",
                fontSize = 20.sp,
                modifier = Modifier
                    .background(Color.Green)
                    .padding(8.dp)
            )
        }
    }
}

